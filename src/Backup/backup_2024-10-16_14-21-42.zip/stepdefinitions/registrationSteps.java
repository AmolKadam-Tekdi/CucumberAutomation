package stepdefinitions;

import io.cucumber.java.en.*;
import utils.baseutils.BrowserManager;

public class registrationSteps extends BrowserManager {
	@Given("user is on the login button")
	public void user_is_on_the_login_button() {
		logStep("user is on the login button");
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


	@When("user click on the sign up button")
	public void user_click_on_the_sign_up_button() {
		logStep("user click on the sign up button");
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


	@When("user enters user's name")
	public void user_enters_user_s_name() {
		logStep("user enters user's name");
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


	@When("user enters email address")
	public void user_enters_email_address() {
		logStep("user enters email address");
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


}
