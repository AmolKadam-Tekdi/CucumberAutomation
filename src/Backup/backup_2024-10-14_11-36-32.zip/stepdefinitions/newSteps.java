package stepdefinitions;

import io.cucumber.java.en.*;

public class newSteps {

	@And("user clicks on the prerak button")
	public void user_clicks_on_the_prerak_button() {
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}

	@Given("kjbsfhgiasigjosdbgkjsdogn onu9wrh gihairugh ia")
	public void kjbsfhgiasigjosdbgkjsdogn_onu9wrh_gihairugh_ia() {
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


	@When("zksdh fihsdigj hrigherh gihwrgh iwjf4")
	public void zksdh_fihsdigj_hrigherh_gihwrgh_iwjf4() {
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


	@Then("lkndfgjoisrh iuhihf go ogoierj gojerog joejrgo er")
	public void lkndfgjoisrh_iuhihf_go_ogoierj_gojerog_joejrgo_er() {
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


}
