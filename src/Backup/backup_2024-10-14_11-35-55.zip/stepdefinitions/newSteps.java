package stepdefinitions;

import io.cucumber.java.en.*;

public class newSteps {

	@And("user clicks on the prerak button")
	public void user_clicks_on_the_prerak_button() {
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}

}
