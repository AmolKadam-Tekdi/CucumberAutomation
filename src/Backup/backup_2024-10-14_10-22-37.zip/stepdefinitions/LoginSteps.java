package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import utils.BaseUtils;
import utils.BrowserManager;

public class LoginSteps extends BrowserManager {

	By usernameField = By.xpath("//*[@placeholder='Enter Username']");
	By passwordField = By.xpath("//*[@placeholder='Enter Password']");
	By loginButton = By.xpath("(//*[text()='Login'])[4]");
	By AcademicYear = By.xpath("//*[text()='Academic Year']");
	By Continue = By.xpath("//*[text()='Continue']");
	By SelectAcademicYear = By.xpath("(//*[@aria-label='Select'])[1]");
	By SelectState = By.xpath("(//*[@aria-label='Select'])[2]");




	@Given("the user is on the login page")
	public void user_is_on_login_page() throws Exception {
		logStep("the user is on the login page");
	}

	@When("the user enters the username {string}")
	public void user_enters_username(String username) throws Exception {
		logStep("the user enters the username ");
		WebElement usernamefield = BaseUtils.driver.findElement(usernameField);
		sendTextOnUI( usernamefield,username);
	}

	@When("the user enters the password {string}")
	public void user_enters_password(String password) {
		logStep("the user enters the password");
		WebElement passwordfield = BaseUtils.driver.findElement(passwordField);
		sendTextOnUI( passwordfield,password);
	}

	@When("the user clicks on the login button")
	public void user_clicks_on_login_button() {
		logStep("the user clicks on the login button");
		WebElement loginbutton = BaseUtils.driver.findElement(loginButton);
		click(loginbutton);
	}

	@Then("the user should see {string} on the home page")
	public void user_sees_academic_year(String expectedText) throws Exception {
		WebElement academicYear = BaseUtils.driver.findElement(AcademicYear);

		String AcademicYeartext = academicYear.getText();
		assertEquals("User is successfully logged in the system",AcademicYeartext," Academic Year","User log in failed");

	}

	@When("the user selects {string} as academic year")
	public void the_user_selects_as_academic_year(String string) {
		logStep("the user selects academic year");
		WebElement selectAcademicYeaR = BaseUtils.driver.findElement(SelectAcademicYear);

		Select sel = new Select(selectAcademicYeaR);
		sel.selectByVisibleText(string);
	}

	@When("User select {string} as State")
	public void user_select_as_state(String string) {
		logStep("User selects State");
		WebElement selectState = BaseUtils.driver.findElement(SelectState);

		Select sel = new Select(selectState);
		sel.selectByVisibleText(string);

	}
	@When("the user clicks on the continue button")
	public void the_user_clicks_on_the_continue_button() {
		logStep("the user clicks on the continue button");
		WebElement continu = BaseUtils.driver.findElement(Continue);
		click(continu);
	}

}
