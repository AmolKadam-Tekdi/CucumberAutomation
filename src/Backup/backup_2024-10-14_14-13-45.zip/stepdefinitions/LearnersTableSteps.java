package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import utils.BaseUtils;
import utils.BrowserManager;

import java.util.concurrent.TimeUnit;

public class LearnersTableSteps extends BrowserManager {
	By LearnerTab = By.xpath("(//*[text()='Learners'])[2]");
	By Identified = By.xpath("//*[text()='Identified']");

	@When("User clicks on the Learners button")
	public void user_clicks_on_the_learners_button() {
		setImplicitWait(10, TimeUnit.SECONDS);

		WebElement learnerTab = BaseUtils.driver.findElement(LearnerTab);
		click(learnerTab);
	}
	@Then("System should display the learner users table to the user")
	public void system_should_display_the_learner_users_table_to_the_user() {
		setImplicitWait(10, TimeUnit.SECONDS);

		WebElement identified = BaseUtils.driver.findElement(Identified);

		assertTrue("Learners table is displayed to the user",isElementDisplayed(identified),"Learners table is not displayed to the user");

	}





	@When("user clicks on the Veiw button for the first user")
	public void user_clicks_on_the_veiw_button_for_the_first_user() {
		// TODO: Implement step
		throw new io.cucumber.java.PendingException();
	}


}
