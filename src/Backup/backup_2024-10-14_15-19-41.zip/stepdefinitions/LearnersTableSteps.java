package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import utils.BaseUtils;
import utils.BrowserManager;

import java.util.concurrent.TimeUnit;

public class LearnersTableSteps extends BrowserManager {
	By LearnerTab = By.xpath("(//*[text()='Learners'])[2]");
	By Identified = By.xpath("//*[text()='Identified']");
	By SelectAcademicYear = By.xpath("(//*[@aria-label='Select'])[1]");
	By SelectState = By.xpath("(//*[@aria-label='Select'])[2]");




}
