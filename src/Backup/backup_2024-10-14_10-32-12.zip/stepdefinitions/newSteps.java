package stepdefinitions;

import io.cucumber.java.en.*;

public class newSteps {

}
