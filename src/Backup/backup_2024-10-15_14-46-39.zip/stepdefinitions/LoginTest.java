package stepdefinitions;

import utils.baseutils.BrowserManager;

public class LoginTest extends BrowserManager {


}
